# Changelog
### CLICK ON REBUILD AFTER ADD-ON UPGRADE
## 0.7
- Solved WARNING (MainThread) [supervisor.addons.validate] Add-on config 'startup' with 'before' is deprecated. Please report this to the maintainer
## 0.6
- Fix template error for multiple thermostats
- Fix template error for thermostats name with spaces
- Fix template lovelace card (each card with same sensors name)

## 0.5

- Fix Boot problem
- Fix Boost Issue

## 0.4

- Fix Start-Up problem
- Add Packages with all sensor, scripts and Climate
- Add Lovelace Card
